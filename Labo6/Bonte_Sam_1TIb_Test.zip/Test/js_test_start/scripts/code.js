const setup = () => {
    //change event en input event
    document.getElementById("selectStaatVanKip")
        .addEventListener("click", veranderStaat);
    document.getElementById("txtInputLetter")
        .addEventListener("change", veranderStaat);

}

const veranderStaat = () => {
    let options = document.getElementById("selectStaatVanKip").options;
    let divImageKip = document.getElementById("img");
    let tekstKip = document.getElementById("note");
    let gezochteLetter = document.getElementById("txtInputLetter";
    tekstKip.textContent = "Hierboven een kip";

    //kijken wat gekozen
    for (let i = 0; i<options.length; i++){
        if(options[i].value === "metEi"){
            divImageKip.className = "";
            divImageKip.innerHTML += "<img src='images/with-egg.png' />";
            tekstKip.textContent += " met een ei"


        } else if (options[i].value === "zonderEi"){
            divImageKip.className = "";
            divImageKip.innerHTML += "<img src='images/without-egg.png'/>";
            tekstKip.textContent += "zonder een ei";
        }
    }
    let aantalVoorkomen = "Letter";
    aantalVoorkomen += letterCount(tekstKip, gezochteLetter);

}

const letterCount = (tekst, zoek) => {
    let result = 0;
    let idx = tekst.indexOf(zoek);
    while (idx !== -1){
        result++;
        idx = tekst.indexOf(zoek, idx+zoek.length);
    }
    return result;
}

window.addEventListener("load", setup);